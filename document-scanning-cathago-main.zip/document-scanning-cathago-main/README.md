# Document Scanning App

Run `npm install`.
Run `node server.js`.
Open `http://localhost:3000` in your browser.
